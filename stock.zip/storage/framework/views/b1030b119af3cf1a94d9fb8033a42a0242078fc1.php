<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="kt-grid__item kt-grid__item--fluid  kt-grid__item--order-tablet-and-mobile-1  kt-login__wrapper">
        <div class="kt-login__head">
            <span class="kt-login__signup-label">Don't have an account yet?</span>&nbsp;&nbsp;
            <a href="<?php echo e(url('registration')); ?>" class="kt-link kt-login__signup-link">Sign Up!</a>
        </div>
        <div class="kt-login__body">
            <div class="kt-login__form">
                <div class="kt-login__title">
                    <h3>Sign In</h3>
                </div>
                <form class="kt-form" action="<?php echo e(url('login')); ?>" novalidate="novalidate" id="kt_login_form" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input class="form-control" type="text" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
                        <?php if($errors->has('email')): ?>
                            <span class="error invalid-feedback d-block"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" placeholder="Password" name="password">

                        <?php if($errors->has('password')): ?>
                            <span class="error invalid-feedback d-block"><?php echo e($errors->first('password')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="kt-login__actions">
                        <a href="<?php echo e(url('forgot-password')); ?>" class="kt-link kt-login__link-forgot">
                            Forgot Password ?
                        </a>
                        <button type="submit" class="btn btn-primary btn-elevate kt-login__btn-primary">Sign In</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.auth.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Laravel\stock\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>