<div class="kt-aside  kt-aside--fixed  kt-grid__item kt-grid kt-grid--desktop kt-grid--hor-desktop"
     id="kt_aside">
    <div class="kt-aside__brand kt-grid__item " id="kt_aside_brand">
        <div class="kt-aside__brand-logo">
            <a href="<?php echo e(url('/')); ?>">
                <img alt="Logo"
                     src="<?php echo e(asset('metronic/theme/default/demo1/dist/assets/media/logos/logo-light.png')); ?>"/>
            </a>
        </div>
        <div class="kt-aside__brand-tools">
            <button class="kt-aside__brand-aside-toggler" id="kt_aside_toggler">
                <span><i class="flaticon-email-black-circular-button"></i></span>
                <span><i class="flaticon-email-black-circular-button"></i></span>
            </button>
        </div>
    </div>
    <div class="kt-aside-menu-wrapper kt-grid__item kt-grid__item--fluid" id="kt_aside_menu_wrapper">
        <div
                id="kt_aside_menu"
                class="kt-aside-menu "
                data-ktmenu-vertical="1"
                data-ktmenu-scroll="1" data-ktmenu-dropdown-timeout="500"
        >
            <ul class="kt-menu__nav ">
                <li class="kt-menu__item <?php echo e(request()->route()->getName() == null  ? 'kt-menu__item--active' : ''); ?> " aria-haspopup="true">
                    <a href="<?php echo e(url('/')); ?>" class="kt-menu__link ">
                        <span class="kt-menu__link-icon"><i class="flaticon-laptop"></i></span>
                        <span class="kt-menu__link-text">Dashboard</span>
                    </a>
                </li>
                <li class="kt-menu__section ">
                    <h4 class="kt-menu__section-text">Menu</h4>
                    <i class="kt-menu__section-icon flaticon-more-v2"></i>
                </li>
                <li class="kt-menu__item <?php echo e(request()->route()->getName() == 'suppliers.index' || request()->route()->getName() == 'suppliers.create' || request()->route()->getName() == 'suppliers.edit' ? 'kt-menu__item--active' : ''); ?> " aria-haspopup="true">
                    <a href="<?php echo e(url('suppliers')); ?>" class="kt-menu__link ">
                        <span class="kt-menu__link-icon"><i class="flaticon2-shopping-cart"></i></span>
                        <span class="kt-menu__link-text">Supplier</span>
                    </a>
                </li>
                <li class="kt-menu__item <?php echo e(request()->route()->getName() == 'customers.index' || request()->route()->getName() == 'customers.create' || request()->route()->getName() == 'customers.edit' ? 'kt-menu__item--active' : ''); ?> " aria-haspopup="true">
                    <a href="<?php echo e(url('customers')); ?>" class="kt-menu__link ">
                        <span class="kt-menu__link-icon"><i class="flaticon2-shopping-cart"></i></span>
                        <span class="kt-menu__link-text">Customer</span>
                    </a>
                </li>
                <li class="kt-menu__item <?php echo e(request()->route()->getName() == 'products.index' || request()->route()->getName() == 'products.create' || request()->route()->getName() == 'products.edit' ? 'kt-menu__item--active' : ''); ?> " aria-haspopup="true">
                    <a href="<?php echo e(url('products')); ?>" class="kt-menu__link ">
                        <span class="kt-menu__link-icon"><i class="flaticon2-shopping-cart"></i></span>
                        <span class="kt-menu__link-text">Product</span>
                    </a>
                </li>
                <li class="kt-menu__item <?php echo e(request()->route()->getName() == 'supplies.index' || request()->route()->getName() == 'supplies.create' || request()->route()->getName() == 'supplies.edit' ? 'kt-menu__item--active' : ''); ?> " aria-haspopup="true">
                    <a href="<?php echo e(url('supplies')); ?>" class="kt-menu__link ">
                        <span class="kt-menu__link-icon"><i class="flaticon2-shopping-cart"></i></span>
                        <span class="kt-menu__link-text">Supply</span>
                    </a>
                </li>
                <li class="kt-menu__item <?php echo e(request()->route()->getName() == 'orders.index' || request()->route()->getName() == 'orders.create' || request()->route()->getName() == 'orders.edit' ? 'kt-menu__item--active' : ''); ?> " aria-haspopup="true">
                    <a href="<?php echo e(url('orders')); ?>" class="kt-menu__link ">
                        <span class="kt-menu__link-icon"><i class="flaticon2-shopping-cart"></i></span>
                        <span class="kt-menu__link-text">Order</span>
                    </a>
                </li>
                <li class="kt-menu__item <?php echo e(request()->route()->getName() == 'categories.index' || request()->route()->getName() == 'categories.create' || request()->route()->getName() == 'categories.edit' ? 'kt-menu__item--active' : ''); ?> " aria-haspopup="true">
                    <a href="<?php echo e(url('categories')); ?>" class="kt-menu__link ">
                        <span class="kt-menu__link-icon"><i class="flaticon2-shopping-cart"></i></span>
                        <span class="kt-menu__link-text">Category</span>
                    </a>
                </li>












































































































































            </ul>
        </div>
    </div>
</div>
<?php /**PATH F:\Projects\Laravel\stock\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>