@extends('admin.master')

@section('title')
    Dashboard
@endsection
