<?php if( Session::has( 'success' )): ?>
    <div class="alert alert-success" role="alert">
        <div class="alert-text"><?php echo e(Session::get( 'success' )); ?>!</div>
    </div>



<?php endif; ?>
<?php if( Session::has( 'warning' )): ?>



    <div class="alert alert-warning" role="alert">
        <div class="alert-text"><?php echo e(Session::get( 'warning' )); ?>!</div>
    </div>
<?php endif; ?><?php /**PATH F:\Projects\Laravel\stock\resources\views/admin/includes/flashMessage.blade.php ENDPATH**/ ?>